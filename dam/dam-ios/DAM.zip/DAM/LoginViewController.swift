//
//  LoginViewController.swift
//  DAM
//
//  Created by Mac-Mini-2021 on 6/11/2024.
//

import UIKit


    class LoginViewController: UIViewController {

        // IBOutlet pour le champ Password (assure-toi que cet IBOutlet est bien relié dans le storyboard)
        @IBOutlet weak var Password: UITextField!
        @IBOutlet weak var Email: UITextField!
        
       
        
        @IBAction func loginButtonTapped(_ sender: Any) {
            var emailO = Email.text
            var Passwordlo = Password.text
            let parameters: [String: Any] = [
                     
                     "email": emailO!,
                     "password": Passwordlo,
                    
                 ]
            
            // Vérifier si tous les champs sont remplis
            if emailO?.isEmpty == true || Passwordlo?.isEmpty == true  {
                // Afficher une alerte si un champ est vide
                showAlert(title: "Missing informations .", message: "Please fill all the fields.")
                
            }
            else {
                showAlert(title: "Succes", message: "Welcome back !")
            }
            
           // sendSignupRequest(parameters: parameters)
        }
        
        func showAlert(title: String, message: String) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        
       
        
        /*
        @IBAction func loginButtonTapped(_ sender: UIButton) {
            guard let emailLo = Email.text, !emailLo.isEmpty,
                  let password = Password.text, !password.isEmpty else {
                print("Nom d'utilisateur ou mot de passe vide")
                return
            }
            login(emailLo: emailLo, password: password)
        }
        
         */
        override func viewDidLoad() {
            
          //  addIconToTextField(Email, iconName: "envelope.fill")
           // addIconToTextField(Password, iconName: "lock.fill")
            super.viewDidLoad()
            
            // Créer le bouton pour basculer la visibilité du mot de passe
            let toggleButton = UIButton(type: .system)
            toggleButton.setImage(UIImage(systemName: "eye.slash"), for: .normal) // Icône œil barré
            toggleButton.addTarget(self, action: #selector(togglePasswordVisibility), for: .touchUpInside)
            
            // Ajouter le bouton en tant que vue de droite du UITextField
            Password.rightView = toggleButton
            Password.rightViewMode = .always
            Password.isSecureTextEntry = true // Masquer le mot de passe par défaut
        }

        // Action pour basculer la visibilité du mot de passe
        @objc private func togglePasswordVisibility() {
            Password.isSecureTextEntry.toggle() // Bascule entre masqué et visible

            // Mettre à jour l’icône du bouton en fonction de l’état
            if let button = Password.rightView as? UIButton {
                let buttonImageName = Password.isSecureTextEntry ? "eye.slash" : "eye"
                button.setImage(UIImage(systemName: buttonImageName), for: .normal)
            }
        }
       
        
        // Sends the signup request to the server
        private func sendSignupRequest(parameters: [String: Any]) {
            guard let url = URL(string: "http://172.18.8.47:3000/auth/login") else { return }

            do {
                let jsonData = try JSONSerialization.data(withJSONObject: parameters, options: [])

                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.httpBody = jsonData
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")

                let task = URLSession.shared.dataTask(with: request) { data, response, error in
                    if let error = error {
                        print("Error: \(error.localizedDescription)")
                        return
                    }

                    guard let data = data else {
                        print("No data received")
                        return
                    }

                    self.handleResponse(data: data)
                }

                // Start the request task
                task.resume()

            } catch {
                print("Error serializing JSON: \(error.localizedDescription)")
            }
        }

        // Handles the response from the server
        private func handleResponse(data: Data) {
            if let responseString = String(data: data, encoding: .utf8) {
                print("Response: \(responseString)")

                // Attempt to parse the response as JSON
                if let jsonData = responseString.data(using: .utf8) {
                    do {
                        if let jsonResponse = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                            // Check the status code
                            if let statusCode = jsonResponse["statusCode"] as? Int {
                                // If status code is 200, perform the segue to "home"
                                print(statusCode)
                                if statusCode == 200 {
                                    print("login is done sucessfully")
                                    DispatchQueue.main.async {
                                        // Perform the segue to "home"
                                        self.performSegue(withIdentifier: "home", sender: nil)
                                    }
                                } else if statusCode == 400  || statusCode ==   401  {
                                    // Handle the specific action for status code 400 (e.g., Email already in use)
                                   
                                }
                            }
                        }
                    } catch {
                        print("Failed to parse JSON: \(error.localizedDescription)")
                    }
                }
            }
        }
        
        
        /*
        func login(emailLo: String, password: String) {
            // Configurez l'URL de votre API
            guard let url = URL(string: "http://172.18.8.47:3000/auth/login") else { return }

            // Configurez la requête
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")

            // Encodez les données utilisateur
            let loginData = LoginRequest(emailLo: emailLo, password: password)
            guard let httpBody = try? JSONEncoder().encode(loginData) else { return }
            request.httpBody = httpBody

            // Envoyez la requête
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if let error = error {
                    print("Erreur de connexion : \(error.localizedDescription)")
                    return
                }

                guard let data = data else { return }

                do {
                    let loginResponse = try JSONDecoder().decode(LoginResponse.self, from: data)
                    print("Token de connexion : \(loginResponse.token)")
                    DispatchQueue.main.async {
                        // Traitez le token ou passez à l'écran suivant
                    }
                } catch {
                    print("Erreur de décodage : \(error)")
                }
            }.resume()
        }
         */
    }
