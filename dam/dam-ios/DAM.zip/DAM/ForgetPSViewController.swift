//
//  ForgetPSViewController.swift
//  DAM
//
//  Created by Apple Esprit on 7/11/2024.
//

import UIKit

class ForgetPSViewController: UIViewController, UITextFieldDelegate {
    /*
    
    @IBOutlet weak var otpSMS: UITextField!
 
  
    var code :Int!
  
    
    // Placeholder labels
    private var newpasswordPlaceholderLabel: UILabel!
    private var confirmNewpasswordPlaceholderLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        addIcon(textField: otpSMS, iconName: "message.fill")
      
        
        // Set the text field delegates
        otpSMS.delegate = self
        
        
        
        
    }
    
    func addIcon(textField: UITextField, iconName: String) {
        // Create the SF Symbol icon as an UIImageView
        let icon = UIImage(systemName: iconName)
        let iconView = UIImageView(image: icon)
        iconView.tintColor = UIColor(red: 130/255, green: 160/255, blue: 255/255, alpha: 1.0) // Set icon color
        iconView.contentMode = .scaleAspectFit
        iconView.frame = CGRect(x: 10, y: 0, width: 24, height: 24)  // Adjust size if needed
        // Create a container view for padding
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 34, height: 24))  // 24 width + 10 padding
        paddingView.addSubview(iconView)
        
        // Set the container view as the left view
        textField.leftView = paddingView
        textField.leftViewMode = .always
        
    }
    
    
    
    // Helper function to get the correct placeholder label
    private func getPlaceholderLabel(for textField: UITextField) -> UILabel? {
        if textField == otpSMS {
            return confirmNewpasswordPlaceholderLabel
        }
        return nil
    }
   
    
    private func isValidPhoneNumber(_ phoneNumber: String) -> Bool {
        let phonePattern = "^[0-9]{8,15}$"
        let phonePred = NSPredicate(format: "SELF MATCHES %@", phonePattern)
        return phonePred.evaluate(with: phoneNumber)
    }
    
    // Function to restrict text field input to only numeric characters
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // Apply numeric-only validation for the otpSMS field
        if textField == otpSMS {
            // Allow only numeric characters
            let characterSet = CharacterSet(charactersIn: "0123456789")
            let filtered = string.rangeOfCharacter(from: characterSet.inverted)
            
            // If the replacement string contains non-numeric characters, return false to prevent the change
            if filtered != nil {
                return false
            }
            
            // Restrict the input to 15 characters maximum
            if let currentText = textField.text, currentText.count >= 15 && !string.isEmpty {
                return false // Reject input if there's already 15 characters
            }
        }
        
        return true
    }
    
    
    
  /*
    // Continue button action to validate fields
    @IBAction func continueAction(_ sender: Any) {
        
        
        guard let smsText = otpSMS.text else {
            
            return
        }
        
        // Check if at least one field is valid
        if  smsText.isEmpty {
            
            
            let parameters: [String: Any] = [
                "email": emailText,
            ]
            email = emailText
            sendSignupRequest(parameters: parameters)
            
            
            
            // Proceed with OTP sending if either email or phone number is valid
            // Example: sendOTP(email: emailText, phone: smsText)
        } else {
            // Show alert if neither field is valid
            showAlert(message: "Please enter a valid email or phone number.")
        }
        
    }
    */
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "otp"{
            if let (code) = sender as? (String) {
                let destination = segue.destination as! RecupCodeViewController
                destination.email = email
                destination.otp = code
                print(code,"________________________________")
            } else {
                print("Sender does not contain the expected data")
            }
        }
    }
    
    // Helper function to show alerts
    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Invalid Input", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    // Sends the signup request to the server
    private func sendSignupRequest(parameters: [String: Any]) {
        guard let url = URL(string: "http://172.18.8.47:3000/auth/forgot-password") else { return }
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: parameters, options: [])
            print("sendSignup" ,jsonData)
            
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.httpBody = jsonData
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            print(jsonData)
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    print("Error: \(error.localizedDescription)")
                    return
                }
                
                guard let data = data else {
                    print("No data received")
                    return
                }
                
                self.handleResponse(data: data)
                
            }
            
            // Start the request task
            task.resume()
            
        } catch {
            print("Error serializing JSON: \(error.localizedDescription)")
        }
    }
    
    // Handles the response from the server
    private func handleResponse(data: Data) {
        struct ForgotPasswordData: Decodable {
            let code: Int
            let user : String
            
        }
        if let responseString = String(data: data, encoding: .utf8) {
            print("Response: \(responseString)")
            
            
            // code = responseString.codingKey[]
            
            // Attempt to parse the response as JSON
            if let jsonData = responseString.data(using: .utf8) {
                print ("_______________________________>1")
                
                do {
                    if let jsonResponse = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                        // Vérifier le code de statut
                        print ("_______________________________>2")
                        
                        if let statusCode = jsonResponse["statusCode"] as? Int {
                            print("Status Code: \(statusCode)")
                            print ("_______________________________>33")
                            
                            if statusCode == 200 {
                                print("Inscription réussie")
                                
                                // Extraire l'ID utilisateur et effectuer la transition si disponible
                                /* if let userId = jsonResponse["userId"] as? String {
                                 DispatchQueue.main.async {
                                 self.performSegue(withIdentifier: "home", sender: userId)
                                 }
                                 }*/
                                
                                // Décoder le JSON pour obtenir d'autres informations (ex: code)
                                // if let jsonData = responseString.data(using: .utf8) {
                                //    if  let yesser = try JSONDecoder().decode(ForgotPasswordData.self, from: jsonData){
                                if let code = jsonResponse["code"] as? Int
                                    {
                                    
                                    print("---------------------------------------")
                                    DispatchQueue.main.async {
                                        self.performSegue(withIdentifier: "otp", sender: (code))
                                    }
                                }
                                
                            } else if statusCode == 400 || statusCode == 401 {
                                // Gérer le cas des codes de statut 400 ou 401
                                print("Veuillez entrer un email valide.")
                                DispatchQueue.main.async {
                                    self.showAlert(message: "Email non existant.")
                                    // Ou activer les modifications d'interface utilisateur
                                    // self.wrong_outlet.text = "Identifiants incorrects"
                                    // self.wrong_outlet.setNeedsLayout()
                                    // self.wrong_outlet.layoutIfNeeded()
                                }
                            }
                        }
                    }
                } catch {
                    print("Échec de l'analyse JSON: \(error.localizedDescription)")
                }
            }
            
        }
    }
     */
}
         
        
        

    
