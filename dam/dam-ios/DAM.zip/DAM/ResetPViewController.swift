//
//  ResetPViewController.swift
//  DAM
//
//  Created by Mac-Mini-2021 on 6/11/2024.
//


import UIKit

class ResetPViewController: UIViewController {
    
    
    @IBOutlet weak var psw1: UITextField!
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // Créer le bouton pour basculer la visibilité du mot de passe
         let toggleButton = UIButton(type: .system)
         toggleButton.setImage(UIImage(systemName: "eye.slash"), for: .normal) // Icône œil barré
         toggleButton.addTarget(self, action: #selector(togglePasswordVisibility), for: .touchUpInside)
         
         // Ajouter le bouton en tant que vue de droite du UITextField
         psw1.rightView = toggleButton
         psw1.rightViewMode = .always
         psw1.isSecureTextEntry = true // Masquer le mot de passe par défaut
        
     
         
         }
         
         // Action pour basculer la visibilité du mot de passe
         @objc private func togglePasswordVisibility() {
         psw1.isSecureTextEntry.toggle() // Bascule entre masqué et visible
             
         
         
         // Mettre à jour l’icône du bouton en fonction de l’état
         if let button = psw1.rightView as? UIButton {
         let buttonImageName = psw1.isSecureTextEntry ? "eye.slash" : "eye"
         button.setImage(UIImage(systemName: buttonImageName), for: .normal)
         }
             
           
         
         }
         
    }
    

